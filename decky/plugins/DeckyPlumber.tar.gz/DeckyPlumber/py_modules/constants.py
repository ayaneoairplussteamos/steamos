from enum import Enum

class DefaultSettings(Enum):
  ALWAYS_USE_DEFAULT = 'ALWAYS_USE_DEFAULT'