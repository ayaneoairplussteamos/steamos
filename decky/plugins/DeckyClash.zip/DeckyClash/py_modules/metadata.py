PACKAGE_NAME = "DeckyClash"
PACKAGE_REPO = "chenx-dust/DeckyClash"
CORE_REPO = "MetaCubeX/mihomo"
YQ_REPO = "mikefarah/yq"
