# fuse

copy from [adjustor](https://github.com/hhd-dev/adjustor)
