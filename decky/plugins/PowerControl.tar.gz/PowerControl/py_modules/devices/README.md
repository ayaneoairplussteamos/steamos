# Devices

## AYANEO devices supports bypass power supply ec version
Air1S 8.4.0.0.27
Air 3.1.0.4.78
AirPlus 1B
Slide 1B
AirPlusMendocino 7.0.0.0.13
AirPlusIntel 0B (?)
FlipKB 8.7.0.0.33
FlipDS 8.7.0.0.33
Kun 8.3.0.0.63
